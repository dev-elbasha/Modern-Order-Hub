import type { ReactNode } from "react";
import { Heart, Menu, Moon, Search, ShoppingBag, Sun, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Footer } from "./Shared";
import { useStorefront } from "../../state/StorefrontContext";

function NavigationLinks() {
  const { t } = useStorefront();
  return (
    <>
      <Link href="/shop">{t.shop}</Link>
      <Link href="/about">{t.about}</Link>
      <Link href="/story">{t.story}</Link>
      <Link href="/journal">{t.journal}</Link>
      <Link href="/contact">{t.contact}</Link>
    </>
  );
}

export function SiteHeader() {
  const {
    t,
    rtl,
    locale,
    setLocale,
    theme,
    toggleTheme,
    favorites,
    totalItems,
    menuOpen,
    setMenuOpen,
  } = useStorefront();

  return (
    <>
      <div className="announcement">
        {rtl
          ? "علامة مصرية للأغذية الطبيعية · تفاصيل المتجر قيد التأكيد"
          : "Egyptian natural-food brand · storefront details being confirmed"}
      </div>
      <header className="header">
        <div className="wrap nav-row">
          <button
            className="icon-btn mobile-menu"
            aria-label={menuOpen ? t.close : t.mobileMenu}
            data-testid="button-mobile-menu"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <Link href="/" className="wordmark" data-testid="link-wordmark">
            COUNTRY&apos;S
          </Link>
          <nav className="nav-links" aria-label="Primary navigation">
            <NavigationLinks />
          </nav>
          <div className="header-actions">
            <Link
              href="/search"
              className="icon-link"
              aria-label={t.search}
              data-testid="link-search"
            >
              <Search size={19} />
            </Link>
            <Link
              href="/favorites"
              className="icon-link"
              aria-label={t.favorites}
              data-testid="link-favorites"
            >
              <Heart size={19} />
              {favorites.length > 0 && (
                <span className="count">{favorites.length}</span>
              )}
            </Link>
            <Link
              href="/cart"
              className="icon-link"
              aria-label={t.cart}
              data-testid="link-cart"
            >
              <ShoppingBag size={19} />
              {totalItems > 0 && <span className="count">{totalItems}</span>}
            </Link>
            <button
              className="icon-btn theme-toggle"
              onClick={toggleTheme}
              aria-label={theme === "dark" ? "Use light theme" : "Use dark theme"}
              title={theme === "dark" ? "Light theme" : "Dark theme"}
              data-testid="button-theme"
            >
              {theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
            </button>
            <button
              className="icon-btn"
              onClick={() => setLocale(locale === "ar" ? "en" : "ar")}
              aria-label={t.language}
              data-testid="button-language"
            >
              {rtl ? "EN" : "ع"}
            </button>
          </div>
        </div>
        {menuOpen && (
          <nav className="mobile-nav wrap" aria-label="Mobile navigation">
            <NavigationLinks />
          </nav>
        )}
      </header>
    </>
  );
}

export function SiteShell({ children }: { children: ReactNode }) {
  const { rtl, t } = useStorefront();
  const [location] = useLocation();
  return (
    <div dir={rtl ? "rtl" : "ltr"}>
      <SiteHeader />
      <div className="route-transition" key={location}>
        {children}
      </div>
      <Footer t={t} />
    </div>
  );
}
